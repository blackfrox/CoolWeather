# CoolWeather

天气获取失败，原因： api问题导致某些地区的天气信息无法获取
