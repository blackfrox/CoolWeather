package com.example.coolweather.base


interface BasePresenter {
    fun start()
}