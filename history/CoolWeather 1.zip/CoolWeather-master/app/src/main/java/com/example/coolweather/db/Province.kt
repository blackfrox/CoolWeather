package com.example.coolweather.db

import org.litepal.crud.DataSupport

/**
 * Created by Administrator on 2018/4/11 0011.
 */
class Province(var name: String,var code: Int,var id: Int=0): DataSupport()